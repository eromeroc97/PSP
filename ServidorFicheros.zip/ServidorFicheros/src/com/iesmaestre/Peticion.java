
package com.iesmaestre;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;


public class Peticion implements Runnable{

    private final Socket socket;
    private OutputStream os;
    private InputStream is;
    private PrintWriter pw;
    private BufferedReader bfr;

    Peticion(Socket conexionEntrante) throws IOException {
        this.socket=conexionEntrante;
        this.construirFlujos();
    }

    private void construirFlujos() throws IOException{
        os=socket.getOutputStream();
        is=socket.getInputStream();
        
        pw =Utilidades.getPrintWriter(os);
        bfr=Utilidades.getBufferedReader(is);
    }
    @Override
    public void run() {
        String linea=this.bfr.readLine();
        while (!linea.equals(Constantes.FIN)){
            if (linea.equals(Constantes.LISTAR)){
                enviarListadoFicheros();
            }
        }
    }

    private void enviarListadoFicheros() {
        String directorioFicheros;
        directorioFicheros="C:\\Users\\ogomez\\Documents\\servidorficheros";
        /* Primero averiguarmos cuantos ficheros
        hay en dicha carpeta y enviamos ese número al cliente        */
        
        /* Despues, si hay ficheros, averiguamos los nombres
        y vamos enviando los nombres al cliente*/
        
    }

}
