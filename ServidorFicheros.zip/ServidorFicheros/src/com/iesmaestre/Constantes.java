
package com.iesmaestre;


public class Constantes {
    public static final int PUERTO_FICHEROS=9876;
    public static final String EXITO    ="OK"   ;
    public static final String ERROR    ="FAIL" ;
    public static final String FIN      ="FIN"  ;
    public static final String LISTAR   ="DIR"  ;
    public static final String GET      ="GET"  ;
            
}
