
package com.iesmaestre.servidordiccionario;


public class Constantes {
    public static final int PUERTO_SERVICIO=9876;
}
